# 6650Project2gRPC_multithread
Please read executive summary for details.
